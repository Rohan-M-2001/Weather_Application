package com.example.Location.Management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocationManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocationManagementApplication.class, args);
	}

}
